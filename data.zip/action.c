Action()
{

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_custom_request("token", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1/04uwuBXyN78nwLWMqHAoH9CmGJNYc1uguygWqSCHB8Q", 
		LAST);

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=74", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("token_2", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1/04uwuBXyN78nwLWMqHAoH9CmGJNYc1uguygWqSCHB8Q&scope=https://www.googleapis.com/auth/userinfo.profile", 
		LAST);

	web_custom_request("token_3", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1/04uwuBXyN78nwLWMqHAoH9CmGJNYc1uguygWqSCHB8Q&scope=https://www.googleapis.com/auth/chromesync", 
		LAST);

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI7wELbU4Dgvyf7iP-TaXzi4fJrAmhWSAVnVR371dLGkxaSziV41gSEzaE_W2JWDf5vrcM3E9_Q6HC1zBbiHXDPxyMEtE6O8r_jp8hbcR1zRK3XU1sHoMnuiMr0QZni0UnSQnyMW7YGB_P0i-pkmQzdA1BVOBY5xdfSOO08kQPZsy_YkUX0; DOMAIN=accounts.google.com");

	web_add_cookie("SID=agfa7uoUw_Dp5LER5DHwhsE5ZBMJTABjYuw5bj2Xw7GbP_ApxxtJyZgYqL-3oVJqboUWdw.; DOMAIN=accounts.google.com");

	web_add_cookie("HSID=AR3gDnnBDW1uc1iXw; DOMAIN=accounts.google.com");

	web_add_cookie("SSID=AZ70jqvnOdql28yTH; DOMAIN=accounts.google.com");

	web_add_cookie("APISID=irDfDf4WbkJnE5RV/AfHVLwg21J9Mx2-WU; DOMAIN=accounts.google.com");

	web_add_cookie("SAPISID=WiYsCv-2UfP0v7Ys/A9EvFAu2SJWejZyaG; DOMAIN=accounts.google.com");

	web_add_cookie("LSID=doritos|lso|o.mail.google.com|s.NZ|s.youtube|ss:agfa7tJbCmFp51LKSVY6F45kgKaP3yNfdID6TEo-RQ25pRb254RAvFgmXfY_ynZFlSqZBw.; DOMAIN=accounts.google.com");

	web_add_cookie("ANID=AHWqTUkLs0pKG7JzR3MmHPcFn_qipjFjJGV6QBCPVeiKpQSgSjQyU0g2msWErz8c; DOMAIN=accounts.google.com");

	web_add_cookie("GAPS=1:RsGPo3OZ35q_aLyWxErAOCIUmtA8W9FhUYVRI8ZtBepJWgamo5jDldEf0CR-TrcA35tql42VrcTlkWQYHwLDmFC8g8ASMg:jKZNF2cW3Wpd5pEw; DOMAIN=accounts.google.com");

	web_add_cookie("NID=185=Rizw8BKhYHzfZ96T-zWEw8tVpdKXKjhE-VFm2Xry6ve-NF8knRmHpJJwnh3Tu-7Sop2xy633y8tFaaFl-DiQpNDsL0-VNqZO_BkyD0bifbI4xc1E7JsvPhYeCVIPLLJlTm_G0sbLkTx9R9C-eeOiHaglok8ODUed-3eTiyFVJ7j8GSWPF3ZmQk3QBnNCo0gkvOYOh0V0BPAbKcN72vhPXQ; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2019-06-15-02; DOMAIN=accounts.google.com");

	web_add_cookie("SIDCC=AN0-TYullobzt-WwGwC47FO277EK12yVjFPmLBp20Cl_y3fLovZaqPe7m7FeP-_USCgio-ZTBA; DOMAIN=accounts.google.com");

	web_add_header("Origin", 
		"https://www.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("www.resenetechspec.com", 
		"URL=https://www.resenetechspec.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://fonts.googleapis.com/css?family=EB+Garamond&subset=latin,cyrillic,latin-ext", ENDITEM, 
		"Url=https://www.google-analytics.com/analytics.js", ENDITEM, 
		"Url=https://www.google-analytics.com/r/collect?v=1&_v=j76&a=1379619709&t=pageview&_s=1&dl=https%3A%2F%2Fwww.resenetechspec.com%2F&ul=en-us&de=UTF-8&dt=Welcome%20to%20Resene%20Techspec%20-%20Resene%20TechSpec%20System&sd=24-bit&sr=1280x800&vp=1263x689&je=0&_u=IEBAAAAB~&jid=1308919524&gjid=889468754&cid=151038827.1560567726&tid=UA-49289843-1&_gid=1680992500.1560567726&_r=1&z=1424434263", ENDITEM, 
		"Url=/favicon.ico", ENDITEM, 
		LAST);

	web_url("userinfo", 
		"URL=https://www.googleapis.com/oauth2/v1/userinfo", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("token_4", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1/04uwuBXyN78nwLWMqHAoH9CmGJNYc1uguygWqSCHB8Q&scope=https://www.googleapis.com/auth/android_checkin+https://www.googleapis.com/auth/gcm", 
		LAST);

	web_custom_request("issuetoken", 
		"URL=https://oauthaccountmanager.googleapis.com/v1/issuetoken", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"Body=force=false&response_type=token&scope=https://www.googleapis.com/auth/calendar.readonly+https://www.googleapis.com/auth/cast-edu-messaging+https://www.googleapis.com/auth/clouddevices+https://www.googleapis.com/auth/hangouts+https://www.googleapis.com/auth/hangouts.readonly+https://www.googleapis.com/auth/meetings+https://www.googleapis.com/auth/plus.peopleapi.readwrite+https://www.googleapis.com/auth/userinfo.email&client_id="
		"919648714761-55j965o0km033psv3i9qls5mo3qtdrb0.apps.googleusercontent.com&origin=pkedcjkdefgpdelpbcmbmeomcjbeemfm&device_id=10363747-8782-41e3-9713-3c1f6ea33eb5&device_type=chrome&lib_ver=extension", 
		EXTRARES, 
		"Url=https://www.resenetechspec.com/Content/images/gradient_background_bg.jpg", "Referer=https://www.resenetechspec.com/Content/site.css?ver=1", ENDITEM, 
		"Url=https://www.resenetechspec.com/engine1/pause.png", "Referer=https://www.resenetechspec.com/engine1/style.css?ver=1", ENDITEM, 
		LAST);

	return 0;
}